# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('portal', '0002_auto_20151110_1148'),
    ]

    operations = [
        migrations.RenameField(
            model_name='liquidacion',
            old_name='seg_cesantia',
            new_name='seguro_cesantia',
        ),
    ]
