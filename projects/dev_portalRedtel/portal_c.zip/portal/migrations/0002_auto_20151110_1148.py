# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('portal', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='usuario',
            name='Afp_id',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='usuario',
            name='Area_id',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='usuario',
            name='Cargo_id',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='usuario',
            name='CentroCosto_id',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='usuario',
            name='Salud_id',
            field=models.IntegerField(),
        ),
    ]
